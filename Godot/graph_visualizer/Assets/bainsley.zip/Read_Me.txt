The Bainsley Font
-------------------------

This is a sans serif font which adopts some of the stylistic elements of a serif font.  It has been on the go a long time but then 2020 didn't go according to plan and there were a lot of other things to take care of and so font design was abandoned for a while.  But now I'm back and I have taken the time to finish Bainsley.

This should have been the Fontlog.txt file but I have lost my original notes from 2018 and can't remember when everything was done so this will have to do.

Bainsley has many open type features and supports many european languages including Greek, Cyrillic and Armenian.

The font has many Kerning Pairs and supports fractions, superscript and subscript.  The small caps and pettite caps features work with all the supported languages.

The starting point for this font was the Ysabeau font by Christian Thalmann.  But this was only a starting point the font has evolved a lot since then.  You can get the original starting point font from :-

https://github.com/CatharsisFonts/Ysabeau

Many thanks to Ruben Hakobyan who gave me a lot of help and advice with the design of the Armenian alphabet.
___________________________________________________________________________________________________________________________________

If you find any bugs in the font please contact me at kelvinch@virginmedia.com 

If any bugs are reported I will attempt to fix them, if no bugs are reported then I may not find them myself and so they will probably not be fixed.

I have included the source files if you want to make any modifications but you will need Font Creator to open these files.  You can get Font Creator at https://www.high-logic.com/font-editor/fontcreator
